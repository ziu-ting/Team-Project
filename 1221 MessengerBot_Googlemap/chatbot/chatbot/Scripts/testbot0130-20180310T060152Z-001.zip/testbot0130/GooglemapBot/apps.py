from django.apps import AppConfig


class GooglemapbotConfig(AppConfig):
    name = 'GooglemapBot'
