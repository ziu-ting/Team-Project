from mapAPI import G_center, G_zoom, request
# import mapAPI

G_center

print(request)

# print(request)
